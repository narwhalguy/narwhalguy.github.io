
//~~~~ VARIABLES ~~~~\\
var timer=0;
var setup = function(){
 createCanvas(500,500);
 var timer=0;
  var player1 = {
  x: 10,
  y: 200,
  w: 15,
  h: 100,
  spd: 3,
  up: false,
  down:false
};
var player2 ={
  x: 475,
  y: 200,
  w: 15,
  h: 100,
  spd: 3,
  up: false,
  down:false
};
var ball = {
  x: 250,
  y: 250,
  w: 20,
  h: 20,
  spdx: Math.random(-3, 3),
  spdy: Math.random(-3, 3)
};
};

var player1 = {
  x: 10,
  y: 200,
  w: 15,
  h: 100,
  spd: 3,
  up: false,
  down:false
};
var player2 ={
  x: 475,
  y: 200,
  w: 15,
  h: 100,
  spd: 3,
  up: false,
  down:false
};
var ball = {
  x: 250,
  y: 250,
  w: 20,
  h: 20,
  spdx: Math.random(-3, 3),
  spdy: Math.random(-3,3)
};

//~~~~ V ~~~~\\
var score1 = 0;
var score2 = 0;


//~~~~ PROGRAM ~~~~\\

var draw = function(){
  background(0);
  timer++
   drawBall();
  drawPlayers();
  if(timer>=120){
  halfline();
  drawBall();
  drawPlayers();
  movePlayers();
  moveBall();
  drawScore();
 }else{
  textSize(32);
  text("Starting in",200,100);
  text("2 Seconds",200,150)
  text("(Use Q&A for controls)",125,200)
 }
};
//~~~~ P ~~~~\\



//~~~~ FUNCTIONS ~~~~\\
function halfline(){
  for (var h = 0; h<15; h++){
    fill(255);
    rect(245,40 *h,10,20);
  }
}
function drawPlayers(){
  fill (255, 255, 255);
  rect(player1.x, player1.y, player1.w, player1.h );
  
  fill (255, 255, 255);
  rect(player2.x, player2.y, player2.w, player2.h );
}


function movePlayers(){ 
  if(player1.up && player1.y> -1){
     player1.y -= player1.spd;
  }
if(player1.down && player1.y < 500 - player1.h){
   player1.y += player1.spd;
}
 if( ball.y < player2.y ){                 
    player2.y -= player2.spd ;      
 }

if(ball.y > player2.y){                   
     player2.y += player2.spd  ;  
}
if(player2.y +100 > 500){
  player2.y = 400
}
}

var keyPressed = function(){
  if(keyCode===38){
    player2.up = true;
  }
  if(keyCode===40){
    player2.down = true;
  }
  if(keyCode===81){
    player1.up = true;
  }
  if(keyCode===65){
    player1.down = true;
}
  
};
var keyReleased = function(){
  if(keyCode===38){
    player2.up = false;
  }
  if(keyCode===40){
    player2.down = false;
  }
  if(keyCode===81){
    player1.up = false;
  }
  if(keyCode===65){
    player1.down = false;
}
  
};
function drawBall(){
  ellipseMode(CORNER);
  fill(255);
  ellipse(ball.x, ball.y, ball.w, ball.h);
}
  function moveBall(){
    ball.x += ball.spdx;
    ball.y += ball.spdy;
    if(ball.x > 500 - ball.w){
     setup();
     ball.x = 250;
     ball.y = 250;
     ball.spdx = Math.random(-3, 3)
     ball.spdy = Math.random(-3,3)
      score1 ++;
    }
    if(ball.x < 0){
      setup();
      ball.x = 250;
     ball.y = 250;
     ball.spdx = Math.random(-3, 3)
     ball.spdy = Math.random(-3,3)
      score2 ++;
    }
    if(ball.y > 500 - ball.h){
      ball.spdy *= -1;
    }
    if(ball.y < 0){
      ball.spdy *= -1;
    }
    if(collision(player1,ball)) {
     ball.spdx *= -1;
     ball.spdx += 0.5;
    }
     if(collision(player2,ball)) {
     ball.spdx *= -1;
     ball.spdx -= 0.5;
    }
  }
  function drawScore(){
    textSize(25);
    fill(255);
    text("P1: "+score1, 10, 25);
    
    fill(255);
    text("P2: "+score2, 420, 25);
  }
  function collision(obj1, obj2){
    if ( obj1.x + obj1.w > obj2.x &&
        obj1.x < obj2.x + obj2.w &&
        obj2.y + obj2.h > obj1.y &&
        obj2.y < obj1.y + obj1.h ) {
      return true;
  } else {
      return false;
  }
  }
  

